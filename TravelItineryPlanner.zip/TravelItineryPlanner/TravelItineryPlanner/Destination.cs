﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelItineryPlanner
{
    public class Destination
    {
        public string Name { get; set; }
        public string Country { get; set; }
        public string Description { get; set; }

        public Destination(string name, string country, string description)
        {
            this.Name = name;
            this.Country = country;
            this.Description = description;
        }

        public override string ToString()
        {
            return "Destination name: "+Name+"\nCountry: "+Country+"\nDescription: "+Description;
        }
    }

   
}
