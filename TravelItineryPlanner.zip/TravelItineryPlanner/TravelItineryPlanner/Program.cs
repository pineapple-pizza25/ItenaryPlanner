﻿using TravelItineryPlanner;

CustomArray<Destination> itinary = new CustomArray<Destination>(10);
bool flag = false;
Console.WriteLine("\n\nWelcome to your itinary planner");

while (!flag)
{
    Console.WriteLine("\n");
    Console.WriteLine("1. Add Destination");
    Console.WriteLine("2. Remove Destination");
    Console.WriteLine("3. View All Destinations");
    Console.WriteLine("4. Search for a Destination");
    Console.WriteLine("5. Exit" +
        "" +
        "" +
        "");
    Console.Write("Choose an option: ");
    var choice = Console.ReadLine();

    switch (choice)
    {
        case "1":

            Console.WriteLine("\n\nEnter destination name:");
            string name = Console.ReadLine();
            Console.WriteLine("What country is this destination in?");
            string country = Console.ReadLine();
            Console.WriteLine("Describe the destination:");
            string descriptions = Console.ReadLine();

            itinary.Add(new Destination(name, country, descriptions));

            break;

        case "2":
            Console.WriteLine("\n\nEnter the index of the destination to remove: ");
            int index = Convert.ToInt32(Console.ReadLine());

            itinary.RemoveAt(index);

            break;

        case "3":
            Console.WriteLine("\n\nHere are your destinations:\n");
            itinary.Print();

            break;

        case "5":

            flag = true;
            Console.WriteLine("\n\nGood bye");

            break;

        default:
            Console.WriteLine("\n\nInvalid choice");

            break;
    }
}